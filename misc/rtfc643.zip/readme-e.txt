Welcome to RTF Converter




[1] Description

  Thank you for trying out RTF Converter.
  This software performs file-type conversion between Text Files and Rich Text Files and character code conversion of Text Files. It supports 92 codepages, including:

    European (Western European, Central European, Baltic, Cyrillic, Greek,
      Turkish, etc.)
    Japanese (Shift-JIS, EUC-JP, ISO-2022-JP)
    Chinese (GB2312, GBK, GB18030, HZ, BIG5)
    Korean (EUC-KR, UHC, ISO-2022-KR, Johab)
    Other Asian Characters (Arabic, Hebrew, Thai, Vietnamese, Devanagari, etc.)
    Unicode (UTF-16, UTF-8)
    Obsolete Codepages (Ascii, Latin 1, Latin 2, Greek, Baltic, Cyrillic,
      Turkish, Portuguese, Icelandic, Canadian French, Nordic, Russian, etc.)
    Macintosh (Western European, Central European, Cyrillic, Greek, Turkish, etc.)

  RTF Converter has two kinds of interface: Dialog Version and Console Version.
  Dialog Version has a visible and simple interface. You can convert files easily with Dialog Version. If you do not have much knowledge about PC, please use Dialog Version.
  Console Version has a character-based interface. It supports wildcards, and it can search for files recursively in subdirectories. (For more information about Console Version, run "rtfconv.com" without arguments.)

  You can use RTF Converter on various platforms. It supports all language versions of Windows 95/98/Me and Windows NT 4.0/2000/XP/Vista. RTF Converter will recognize your PC's configuration automatically. You do not need to mind what languages your OS supports.

  If you want to know how to install and uninstall, go to Installation and Uninstallation.




[2] Installation and Uninstallation

  To install this program, extract all files from the archive and run "setup.exe".
  To remove this program, use the Add/Remove Programs tool in Control Panel.




[3] License

  This is free software. You can use it on any computer, including a computer in a commercial organization. You don't need to register or pay for it. You can redistribute the archive as long as you do not modify its contents.
  I hope that this software will be useful, but without any warranty.




[4] Miscellenea

  You can download the latest version of RTF Converter at:

    http://www5b.biglobe.ne.jp/~harigaya/
    http://www.vector.co.jp/vpack/browse/person/an019647.html

  You can download the documents and source files at:

    http://www5b.biglobe.ne.jp/~harigaya/



  If you have any opinions or questions, please mail to me.
  If you want to ask questions about character conversion, please attach sample files to mail.

    mailto: harigayas@mvi.biglobe.ne.jp

  You may notice that Japanese Help File is longer and more detailed than English Help File. I am not a good English speaker, I don't have enough ability to translate it to good English. I will welcome you to be a volunteer to translate it to English!


                                                     Harigaya Soichi



